<?
$arTemplate = array (
  'NAME' => 'Шаблон news.list',
  'DESCRIPTION' => 'Шаблон news.list для интернет магазина "Одежда"',
  'SORT' => '',
  'TYPE' => '',
);
