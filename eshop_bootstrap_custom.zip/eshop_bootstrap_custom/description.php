<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
$arTemplate = Array(
	"NAME" => "Адаптивный кастомизированный шаблон интернет-магазина"
);?>