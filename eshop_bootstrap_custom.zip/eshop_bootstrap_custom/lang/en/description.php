<?
$MESS["CSST_TEMPLATE_NAME"] = "e-Store template, new rubber layout";
?>