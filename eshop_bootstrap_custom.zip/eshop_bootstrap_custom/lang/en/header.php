<?
$MESS["FOOTER_COMPANY_ABOUT"] = "About Us";
$MESS["FOOTER_COMPANY_PHONE"] = "Contact Us";
$MESS["FOOTER_UP_BUTTON"] = "Up";
$MESS["HEADER_WORK_TIME"] = "Business hours:";
$MESS["SEARCH_GOODS"] = "Products";
$MESS["SEARCH_OTHER"] = "Other";
?>