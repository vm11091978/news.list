<?
$MESS["SEARCH_GOODS"] = "Товары";
$MESS["SEARCH_OTHER"] = "Прочее";
$MESS["FOOTER_COMPANY_ABOUT"] = "Подробнее о компании";
$MESS["FOOTER_COMPANY_PHONE"] = "Свяжитесь с нами";
$MESS["FOOTER_UP_BUTTON"] = "Наверх";
$MESS["HEADER_WORK_TIME"] = "Время работы:";
?>